# R1soft-Certificate
This repo is used to signed certificate to access R1Soft dashboard.
